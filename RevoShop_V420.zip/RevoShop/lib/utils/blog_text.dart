String buildTextButtonPrev(){
  return 'Previous';
}

String buildTextButtonNext(){
  return 'Next';
}

String buildTextLets(){
  return "Let's...";
}

String buildTextHeader(){
  return 'Read Our Blog';
}