String titleViewMore(){
  return 'View More';
}

String subtitleViewMore(){
  return 'View all products in this category';
}