<?php  

	function rest_home(){

		require (plugin_dir_path( __FILE__ ).'../helper.php');

		$rest_slider = rest_slider('get');
		$rest_categories = rest_categories('get');

		$query_ac = "SELECT slug, title, image, description, update_at FROM `revo_mobile_variable` WHERE slug = 'app_color'";
		$data_ac = $wpdb->get_results($query_ac, OBJECT);

		$result['app_color'] = $data_ac;

		$result['main_slider'] = $rest_slider;
		$result['mini_categories'] = $rest_categories;
		$result['mini_banner'] = rest_mini_banner('result');
		$result['general_settings'] = rest_get_general_settings('result');
		$get_intro = rest_get_intro_page('result');
		$result = array_merge($result,$get_intro);


		$revo_loader = load_Revo_Flutter_Mobile_App_Public();
		$result['products_flash_sale'] = rest_product_flash_sale('result',$revo_loader);
		$result['products_special'] = rest_additional_products('result','special',$revo_loader);
		$result['products_our_best_seller'] = rest_additional_products('result','our_best_seller',$revo_loader);
		$result['products_recomendation'] = rest_additional_products('result','recomendation',$revo_loader);

		echo json_encode($result);
		exit();
	}

	function rest_product_details()
	{
		require (plugin_dir_path( __FILE__ ).'../helper.php');
		// $req = (Object) array_merge($_POST,$_GET,$_);
		$revo_loader = load_Revo_Flutter_Mobile_App_Public();
		$search = cek_raw('product_id') ?? get_page_by_path( cek_raw('slug'), OBJECT, 'product' );
		$product = wc_get_product($search);
		//return ['products'=>$revo_loader->get_products(),'id'=>cek_raw('product_id')];
		return $revo_loader->reformat_product_result($product);
	}

	function rest_product_lists()
	{
		require (plugin_dir_path( __FILE__ ).'../helper.php');
		$revo_loader = load_Revo_Flutter_Mobile_App_Public();
		

		$args = [
			'limit'=> cek_raw('perPage') ?? 1,
			'page'=> cek_raw('page') ?? 10,
			'featured' => cek_raw('featured'),
			'category' => cek_raw('category'),
			'orderby' => cek_raw('orderby') ?? 'date',
			'order'  => cek_raw('order') ?? 'DESC',
		];

		if ($parent = cek_raw('parent')) {
			$args['parent'] = $parent;
		}
		if ($include = cek_raw('include')) {
			$args['include'] = $include;
		}
		if ($search = cek_raw('search')) {
			$args['like_name'] = $search;
		}
		
		$products = wc_get_products( $args );
		$results = array();
		foreach ($products as $i => $product) {
			array_push($results,$revo_loader->reformat_product_result($product));
		}

		echo json_encode($results);
		exit;
	}

	
	// function rest_list_product($type = 'rest'){

	// 	require (plugin_dir_path( __FILE__ ).'../helper.php');

	// 	$revo_loader = load_Revo_Flutter_Mobile_App_Public();

	// 	$args = [
	// 		'include' => cek_raw('include'),
	// 		'page' => cek_raw('page') ?? 1,
	// 		'limit' => cek_raw('per_page') ?? 10,
	// 		'parent' => cek_raw('parent'),
	// 		'search' => cek_raw('search'),
	// 		'category' => cek_raw('category'),
	// 		'slug' => cek_raw('slug'),
	// 		'id' => cek_raw('id'),
	// 		'featured' => cek_raw('featured'),
	// 		'order' => cek_raw('order') ?? 'DESC',
	// 		'order_by' => cek_raw('order_by') ?? 'date',
	// 		'attribute' => cek_raw('attribute'),
	// 		'price_range' => cek_raw('price_range')
	// 	];

	// 	$result = $revo_loader->get_products($args);

	// 	if ($type == 'rest') {

	// 		echo json_encode($result);

	// 		exit();

	// 	}else{

	// 		return $result;

	// 	}

	// }


	function rest_additional_products($type = 'rest',$product_type,$revo_loader){
		
		require (plugin_dir_path( __FILE__ ).'../helper.php');

		$where = '';

		if ($product_type == 'special') {
			$where = "AND type = 'special'";
		}elseif ($product_type == 'our_best_seller') {
			$where = "AND type = 'our_best_seller'";
		}elseif ($product_type == 'recomendation') {
			$where = "AND type = 'recomendation'";
		}

		$products = $wpdb->get_results("SELECT * FROM `revo_extend_products` WHERE is_deleted = 0 AND is_active = 1 $where  ORDER BY id DESC", OBJECT);

		$result = [];
		$list_products = [];
		foreach ($products as $key => $value) {

			if (!empty($value->products)) {
				$_POST['include'] = $value->products;
				$list_products = $revo_loader->get_products();
			}


			array_push($result, [
				'title' => $value->title,
				'description' => $value->description,
				'products' => $list_products,
			]);

		}

		if ($type == 'rest') {
			echo json_encode($result);
			exit();
		}else{
			return $result;
		}
	}

	function rest_product_flash_sale($type = 'rest',$revo_loader){
		require (plugin_dir_path( __FILE__ ).'../helper.php');
		cek_flash_sale_end();
		$date = date('Y-m-d H:i:s');
		$data_flash_sale = $wpdb->get_results("SELECT * FROM `revo_flash_sale` WHERE is_deleted = 0 AND start <= '".$date."' AND end >= '".$date."' AND is_active = 1  ORDER BY id DESC LIMIT 1", OBJECT);

		$result = [];
		$list_products = [];
		foreach ($data_flash_sale as $key => $value) {
			if (!empty($value->products)) {
				$_POST['include'] = $value->products;
				$list_products = $revo_loader->get_products();
			}
			array_push($result, [
				'id' => (int) $value->id,
				'title' => $value->title,
				'start' => $value->start,
				'end' => $value->end,
				'image' => $value->image,
				'products' => $list_products,
			]);
		}

		if ($type == 'rest') {
			echo json_encode($result);
			exit();
		}else{
			return $result;
		}
	}

	function index_home(){
		$rest_slider = rest_slider('get');
		$rest_categories = rest_categories('get');

		$result['slider'] = $rest_slider;
		$result['categories'] = $rest_categories;

		echo json_encode($result);
		exit();
	}

	function rest_slider($type = 'rest'){
		require (plugin_dir_path( __FILE__ ).'../helper.php');
		$data_banner = $wpdb->get_results("SELECT * FROM revo_mobile_slider WHERE is_deleted = 0 ORDER BY order_by DESC", OBJECT);
		$result = [];
		foreach ($data_banner as $key => $value) {

			$product_name = explode('|', $value->product_name)[0];
			$link_to = $product_name == 'cat' ? 'category' : 'product';

			array_push($result, [
				'link_to' => $link_to,
				'product' => (int) $value->product_id,
				'title_slider' => $value->title,
				'image' => $value->images_url,
			]);
		}

		if (empty($result)) {
			for ($i=0; $i < 3; $i++) { 
				array_push($result, [
					'product' => (int) '0',
					'title_slider' => '',
					'image' => revo_url().'assets/extend/images/default_banner.png',
				]);
			}
		}

		if ($type == 'rest') {
			echo json_encode($result);
			exit();
		}else{
			return $result;
		}
	}

	function rest_mini_banner($type = 'rest'){
		require (plugin_dir_path( __FILE__ ).'../helper.php');

		$where = '';
		if (isset($_GET['blog_banner'])) {
			$where = "AND type = 'Blog Banner' ";
		}
		$data_banner = $wpdb->get_results("SELECT * FROM revo_list_mini_banner WHERE is_deleted = 0 $where ORDER BY order_by ASC", OBJECT);
		
		$result = [];
		if (isset($_GET['blog_banner'])) {

			foreach ($data_banner as $key => $value) {

				$product_name = explode('|', $value->product_name)[0];
				$link_to = $product_name == 'cat' ? 'category' : 'product';

				if ($value->type == 'Blog Banner') {
					$result[] = [
							'link_to' => $link_to,
							'product' => (int) $value->product_id,
							'title_slider' => ($value->title != NULL ? $value->title : ''),
							'type' => $value->type,
							'image' => $value->image,
						];
				}else{
					$result[] = array(
							'link_to' => '',
							'product' => (int) '0',
							'title_slider' => '',
							'type' => 'Blog Banner',
							'image' => revo_url().'assets/extend/images/defalt_mini_banner.png',
						);
				}

				break;
			}

		}else{
			$result_1 = [];
			$type_1 = 'Special Promo';
			$result_2 = [];
			$type_2 = 'Love These Items';
			
			foreach ($data_banner as $key => $value) {

				$product_name = explode('|', $value->product_name)[0];
				$link_to = $product_name == 'cat' ? 'category' : 'product';
				
				if ($value->type == $type_1) {
					array_push($result_1, [
						'link_to' => $link_to,
						'product' => (int) $value->product_id,
						'title_slider' => ($value->title != NULL ? $value->title : ''),
						'type' => $value->type,
						'image' => $value->image,
					]);
				}

				if ($value->type == $type_2) {
					array_push($result_2, [
						'link_to' => $link_to,
						'product' => (int) $value->product_id,
						'title_slider' => ($value->title != NULL ? $value->title : ''),
						'type' => $value->type,
						'image' => $value->image,
					]);
				}
			}

			if (count($result_1) < 4) {
				$total_result_1 = 4 - count($result_1);
				for ($i=0; $i < $total_result_1; $i++) { 
					array_push($result_1, [
						'link_to' => '',
						'product' => (int) '0',
						'title_slider' => '',
						'type' => $type_1,
						'image' => revo_url().'assets/extend/images/defalt_mini_banner.png',
					]);
				}
			}

			if (count($result_2) < 4) {
				$total_result_2 = 4 - count($result_2);
				for ($i=0; $i < $total_result_2; $i++) {
					array_push($result_2, [
						'link_to' => '',
						'product' => (int) '0',
						'title_slider' => '',
						'type' => $type_2,
						'image' => revo_url().'assets/extend/images/defalt_mini_banner.png',
					]);
				}
			}

			$result = array_merge($result_1,$result_2);
		}

		if ($type == 'rest') {
			echo json_encode($result);
			exit();
		}else{
			return $result;
		}
	}

	function rest_categories($type = 'rest'){
		require (plugin_dir_path( __FILE__ ).'../helper.php');
		$data_banner = $wpdb->get_results("SELECT * FROM revo_list_categories WHERE is_deleted = 0 ORDER BY order_by DESC", OBJECT);
		$result = [];

		if (isset($_GET['show_popular'])) {
			array_push($result, [
				'categories' => (int) '9911',
				'title_categories' => 'Popular Categories',
				'image' => revo_url().'assets/extend/images/popular.png',
			]);
		}

		foreach ($data_banner as $key => $value) {
			array_push($result, [
				'categories' => (int) $value->category_id,
				'title_categories' => $value->category_name,
				'image' => $value->image,
			]);
		}

		if (empty($result)) {
			for ($i=0; $i < 5; $i++) { 
				array_push($result, [
					'categories' => (int) '0',
					'title_categories' => 'Dummy Categories',
					'image' => revo_url().'assets/extend/images/default_categories.png',
				]);
			}
		}

		if ($type == 'rest') {
			echo json_encode($result);
			exit();
		}else{
			return $result;
		}
	}

	function rest_categories_list($type = 'rest'){
		require (plugin_dir_path( __FILE__ ).'../helper.php');
		
		$result = [];

		$taxonomy     = 'product_cat';
        $orderby      = 'name';  
        $show_count   = 1;      // 1 for yes, 0 for no
        $pad_counts   = 0;      // 1 for yes, 0 for no
        $hierarchical = 1;      // 1 for yes, 0 for no  
        $title        = '';  
        $empty        = 0;

        $args = array(
             'taxonomy'     => $taxonomy,
             //'orderby'      => $orderby,
             'show_count'   => $show_count,
             'pad_counts'   => $pad_counts,
             'hierarchical' => $hierarchical,
             'title'     => $title,
             'hide_empty'   => $empty,
             'menu_order' => 'asc',
             'parent' => 0
        );

        if (cek_raw('page')) {
        	$args['offset'] = cek_raw('page');
        }

        if (cek_raw('limit')) {
        	$args['number'] = cek_raw('limit');
        }

        if (!cek_raw('parent')) {
        	$data_categories = get_popular_categories();
			if (!empty($data_categories)) {
				array_push($result, [
					'id' => (int) '9911',
					'title' => 'Popular Categories',
					'description' => '',
					'parent' => 0,
					'count' => 0,
					'image' => revo_url().'assets/extend/images/popular.png',
				]);
			}

       	 	$categories = get_categories( $args );
	 		foreach ($categories as $key => $value) {
	 			if ($value->name != 'Uncategorized') {
	 				$image_id = get_term_meta( $value->term_id, 'thumbnail_id', true );
		            $image = '';

		            if ( $image_id ) {
		                $image = wp_get_attachment_url( $image_id );
		            }

		            $terms = get_terms([
				        'taxonomy'    => 'product_cat',
				        'hide_empty'  => false,
				        'parent'      => $value->term_id
				    ]);


		            array_push($result, [
						'id' => $value->term_id,
		                'title' => wp_specialchars_decode($value->name),
		                'description' => $value->description,
		                'parent' => $value->parent,
		                'count' => count($terms),
		                'image' => $image,
					]);
	 			}
	        }
        }else{
        	$categories = get_terms([
					        'taxonomy'    => 'product_cat',
					        'hide_empty'  => false,
					        'parent'      => cek_raw('parent')
					    ]);

        	foreach ($categories as $key => $value) {
        		$image_id = get_term_meta( $value->term_id, 'thumbnail_id', true );
	            $image = '';

	            if ( $image_id ) {
	                $image = wp_get_attachment_url( $image_id );
	            }


        		array_push($result, [
							'id' => $value->term_id,
			                'title' => wp_specialchars_decode($value->name),
			                'description' => $value->description,
			                'parent' => $value->parent,
			                'count' => 0,
			                'image' => $image,
						]);
        	}

        }

		if ($type == 'rest') {
			echo json_encode($result);
			exit();
		}else{
			return $result;
		}
	}

	function popular_categories($type = 'rest'){
		require (plugin_dir_path( __FILE__ ).'../helper.php');

		$data_categories = get_popular_categories();
		$result = [];
		if (!empty($data_categories)) {
			foreach ($data_categories as $key) {
				$categories = json_decode($key->categories);
				$list = [];
				if (is_array($categories)) {
					for ($i=0; $i < count($categories); $i++) { 
						$image = wp_get_attachment_url(get_term_meta($categories[$i], 'thumbnail_id',true));
						$list[] = array(
									'id' => $categories[$i], 
									'name' => get_terms( 'product_cat', ['include' => $categories[$i], 'hide_empty' => false] , true)[0]->name, 
									'image' => ($image == false ? revo_url().'assets/extend/images/defalt_mini_banner.png' : $image)
								);
					}
					if (!empty($list)) {
						$result[] = array(
									'title' => $key->title,
									'categories' => $list,
								);
					}
				}
			}
		}

		if ($type == 'rest') {
			echo json_encode($result);
			exit();
		}else{
			return $result;
		}
	}

	function rest_flash_sale($type = 'rest'){
		require (plugin_dir_path( __FILE__ ).'../helper.php');
		cek_flash_sale_end();
		$date = date('Y-m-d H:i:s');
		$data_flash_sale = $wpdb->get_results("SELECT * FROM `revo_flash_sale` WHERE is_deleted = 0 AND start <= '".$date."' AND end >= '".$date."' AND is_active = 1  ORDER BY id DESC LIMIT 1", OBJECT);

		$result = [];
		$list_products = [];
		foreach ($data_flash_sale as $key => $value) {
			if (!empty($value->products)) {
				$get_products = json_decode($value->products);
				if (is_array($get_products)) {
					$list_products = implode(",",$get_products);
				}
			}
			array_push($result, [
				'id' => (int) $value->id,
				'title' => $value->title,
				'start' => $value->start,
				'end' => $value->end,
				'image' => $value->image,
				'products' => implode(",",json_decode($value->products)),
			]);
		}

		if ($type == 'rest') {
			echo json_encode($result);
			exit();
		}else{
			return $result;
		}
	}

	function rest_extend_products($type = 'rest'){
		
		require (plugin_dir_path( __FILE__ ).'../helper.php');
		
		$where = '';

		$typeGet = '';
		if (isset($_GET['type'])) {
			$typeGet = $_GET['type'];
			
			if ($typeGet == 'special') {
				$where = "AND type = 'special'";
			}

			if ($typeGet == 'our_best_seller') {
				$where = "AND type = 'our_best_seller'";
			}

			if ($typeGet == 'recomendation') {
				$where = "AND type = 'recomendation'";
			}
		}

		$products = $wpdb->get_results("SELECT * FROM `revo_extend_products` WHERE is_deleted = 0 AND is_active = 1 $where  ORDER BY id DESC", OBJECT);

		$result = [];
		$list_products = "";
		if (!empty($products)) {
			foreach ($products as $key => $value) {
				if (!empty($value->products)) {
					$get_products = json_decode($value->products);
					if (is_array($get_products)) {
						$list_products = implode(",",$get_products);
					}
				}
				array_push($result, [
					'title' => $value->title,
					'description' => $value->description,
					'products' => $list_products,
				]);

			}
		}else{
			array_push($result, [
				'title' => $typeGet,
				'description' => "",
				'products' => "",
			]);
		}

		if ($type == 'rest') {
			echo json_encode($result);
			exit();
		}else{
			return $result;
		}
	}

	function rest_get_barcode($type = 'rest'){
		
		require (plugin_dir_path( __FILE__ ).'../helper.php');
		
		$code = cek_raw('code');

		if (!empty($code)) {
			$table_name = $wpdb->prefix . 'postmeta';

			$get = $wpdb->get_row("SELECT * FROM `$table_name` WHERE `meta_value` LIKE '$code'", OBJECT);
			if (!empty($get)) {
				$result['id'] = (int)$get->post_id;
			}else{
				$result = ['status' => 'error','message' => 'code not found !'];
			}
		}else{
			$result = ['status' => 'error','message' => 'code required !'];
		}

		if ($type == 'rest') {
			echo json_encode($result);
			exit();
		}else{
			return $result;
		}
	}

	function rest_hit_products($type = 'rest'){
		
		require (plugin_dir_path( __FILE__ ).'../helper.php');

		$cookie = cek_raw('cookie');

		$result = ['status' => 'error','message' => 'Login required !'];
		if ($cookie) {
			$user_id = wp_validate_auth_cookie($cookie, 'logged_in');
			if (!$user_id) {
				$result = ['status' => 'error','message' => 'User Tidak ditemukan !'];
			}else{
				$id_product = cek_raw('product_id');
				$ip_address = cek_raw('ip_address');
				
				$result = ['status' => 'error','message' => 'Tidak dapat Hit Products !'];

				if (!empty($id_product) AND !empty($ip_address)) {
					
					$date = date('Y-m-d');

					$products = $wpdb->get_results("SELECT * FROM `revo_hit_products` WHERE products = '$id_product' AND type = 'hit' AND ip_address = '$ip_address' AND user_id = '$user_id' AND created_at LIKE '%$date%'", OBJECT);

					if (empty($products)) {
						
						$wpdb->insert('revo_hit_products',                  
				        [
				            'products' => $id_product,
				            'ip_address' => $ip_address,
				            'user_id' => $user_id,
				        ]);

						if (empty($wpdb->show_errors())) {
							
							$result = ['status' => 'success','message' => 'Berhasil Hit Products !'];

						}else{

							$result = ['status' => 'error','message' => 'Server Error 500 !'];

						}

					}else{

						$result = ['status' => 'error','message' => 'Hit Product Hanya Bisa dilakukan sekali sehari !'];

					}

				}
			}
		}

		if ($type == 'rest') {
			echo json_encode($result);
			exit();
		}else{
			return $result;
		}
	}

	function rest_insert_review($type = 'rest'){
		
		require (plugin_dir_path( __FILE__ ).'../helper.php');

		$cookie = cek_raw('cookie');

		$result = ['status' => 'error','message' => 'Login required !'];
		if ($cookie) {
			$user_id = wp_validate_auth_cookie($cookie, 'logged_in');
			if (!$user_id) {
				$result = ['status' => 'error','message' => 'User Tidak ditemukan !'];
			}else{
				$user = get_userdata($user_id);

				$comment_id = wp_insert_comment( array(
				    'comment_post_ID'      => cek_raw('product_id'), // <=== The product ID where the review will show up
				    'comment_author'       => $user->first_name.' '.$user->last_name,
				    'comment_author_email' => $user->user_email, // <== Important
				    'comment_author_url'   => '',
				    'comment_content'      => cek_raw('comments'),
				    'comment_type'         => '',
				    'comment_parent'       => 0,
				    'user_id'              => $user_id, // <== Important
				    'comment_author_IP'    => '',
				    'comment_agent'        => '',
				    'comment_date'         => date('Y-m-d H:i:s'),
				    'comment_approved'     => 0,
				) );

				// HERE inserting the rating (an integer from 1 to 5)
				update_comment_meta( $comment_id, 'rating', cek_raw('rating') );

				$result = ['status' => 'success','message' => 'insert rating success !'];
			}
		}

		if ($type == 'rest') {
			echo json_encode($result);
			exit();
		}else{
			return $result;
		}
	}

	function rest_get_hit_products($type = 'rest'){
		
		require (plugin_dir_path( __FILE__ ).'../helper.php');

		$cookie = cek_raw('cookie');

		if ($cookie) {
			$user_id = wp_validate_auth_cookie($cookie, 'logged_in');
			if (!$user_id) {
				$result = ['status' => 'error','message' => 'User Tidak ditemukan !'];
			}else{

				$products = $wpdb->get_results("SELECT * FROM `revo_hit_products` WHERE user_id = '$user_id' AND type = 'hit' GROUP BY products ORDER BY created_at DESC", OBJECT);
    
				$list_products = '';

				if (!empty($products)) {
				    $list_products = [];
					foreach ($products as $key => $value) {
						$list_products[] = $value->products;
					}
                    if(!empty($list_products)){
                        $list_products = implode(",",$list_products);
                    }
				}else{
					
					// $where = array(
					// 			'limit' => 10,
					// 			'orderby' => 'rand',
					// 		);

					// $list_products = get_products_id($where);

					// $list_products = implode(",",$list_products);

				}

				$result = [
							'status' => 'success',
							'products' => $list_products,
						];
			}
		}else{
			$result = ['status' => 'error','message' => 'Login required !'];
		}

		if ($type == 'rest') {
			echo json_encode($result);
			exit();
		}else{
			return $result;
		}
	}

	function rest_intro_page_status($type = 'rest'){
		require (plugin_dir_path( __FILE__ ).'../helper.php');
		$get = query_revo_mobile_variable('"intro_page_status"','sort');
		$status = $_GET['status'];
		if (empty($get)) {
			$wpdb->insert('revo_mobile_variable', array(
				'slug' => 'intro_page_status',
				'title' => '',
				'image' => query_revo_mobile_variable('"splashscreen"')[0]->image,
				'description' => $status
			));
		}else {
			$wpdb->query(
				$wpdb
				->prepare("
					UPDATE revo_mobile_variable 
					SET description='$status' 
					WHERE slug='intro_page_status'
				")
			);
		}
		return $status;
	}

	function rest_get_general_settings($type = 'rest'){
		require (plugin_dir_path( __FILE__ ).'../helper.php');

		$query_pp = "SELECT * FROM `revo_mobile_variable` WHERE slug = 'privacy_policy'";
		$data_pp = $wpdb->get_row($query_pp, OBJECT);
		$query_tc = "SELECT * FROM `revo_mobile_variable` WHERE slug = 'term_condition'";
		$data_tc = $wpdb->get_row($query_tc, OBJECT);

		$result['wa'] = data_default_MV('kontak_wa');
		$result['sms'] = data_default_MV('kontak_sms');
		$result['phone'] = data_default_MV('kontak_phone');
		$result['about'] = data_default_MV('about');
		$result['privacy_policy'] = $data_pp ?? data_default_MV('privacy_policy');
		$result['term_condition'] = $data_tc ?? data_default_MV('term_condition');
		$result['cs'] = data_default_MV('cs');
		$result['logo'] = data_default_MV('logo');
		$result['sosmed_link'] = data_default_MV('sosmed_link');
		$result['barcode_active'] = false;

		if ( is_plugin_active( 'yith-woocommerce-barcodes-premium/init.php' ) ) {
			$result['barcode_active'] = true;			
		}
		

	    $get = query_revo_mobile_variable('"kontak","about","cs","privacy_policy","logo","empty_image","term_condition","searchbar_text","sosmed_link"','sort');

		if (!empty($get)) {
			foreach ($get as $key) {

				if ($key->slug == 'kontak') {
					$result[$key->title] = [
											  'slug' => $key->slug, 
											  "title" => $key->title,
											  "image" => $key->image,
											  "description" => $key->description
											];
				}else{
					if ($key->slug == 'empty_image') {
						$result[$key->slug][] = [
											  'slug' => $key->slug, 
											  "title" => $key->title,
											  "image" => $key->image,
											  "description" => $key->description
											];
					}else{
						$result[$key->slug] = [
											  'slug' => $key->slug, 
											  "title" => $key->title,
											  "image" => $key->image,
											  "description" => $key->description
											];
					}
				}

				if ($key->slug == 'searchbar_text') {

					$result[$key->slug] = [
						'slug' => $key->slug, 
						"title" => $key->title,
						"description" => json_decode($key->description)
					];
				}

				if ($key->slug == 'sosmed_link') {

					$result[$key->slug] = [
						'slug' => $key->slug, 
						"title" => $key->title,
						"description" => json_decode($key->description)
					];
				}
			}

			$result["link_playstore"] = [
							  'slug' => "playstore", 
							  "title" => "link playstore",
							  "image" => "",
							  "description" => "https://play.google.com/store"
							];
			$currency = get_woocommerce_currency_symbol();

			$result["currency"] = [
							  'slug' => "currency", 
							  "title" => generate_currency(get_option('woocommerce_currency')),
							  "image" => generate_currency(wp_specialchars_decode(get_woocommerce_currency_symbol($currency))),
							  "description" => generate_currency(wp_specialchars_decode($currency)),
							  "position" => get_option('woocommerce_currency_pos')
							];

			$result["format_currency"] = [
							  'slug' => wc_get_price_decimals(), 
							  "title" => wc_get_price_decimal_separator(),
							  "image" => wc_get_price_thousand_separator(),
							  "description" => "Slug : Number of decimals , title : Decimal separator, image : Thousand separator"
							];
		}

		if (empty($result['empty_image'])) {
			$result['empty_image'][] = data_default_MV('empty_images_1');
			$result['empty_image'][] = data_default_MV('empty_images_2');
			$result['empty_image'][] = data_default_MV('empty_images_3');
			$result['empty_image'][] = data_default_MV('empty_images_4');
			$result['empty_image'][] = data_default_MV('empty_images_5');
		}

		if ($intro_page) {
			for ($i=1; $i < 4; $i++) { 
				$result['intro'][] = data_default_MV('intro_page_'.$i);
			}
		}

		if ($type == 'rest') {
			echo json_encode($result);
			exit();
		}else{
			return $result;
		}
	}

	function generate_currency($currency){

		if ($currency == 'AED') {
			$result = 'د.إ';
		} else {
			$result = $currency;
		}

		return $result;

	}


	function rest_get_intro_page($type = 'rest'){
		
		require (plugin_dir_path( __FILE__ ).'../helper.php');

		$get = query_revo_mobile_variable('"intro_page","splashscreen"','sort');

		$result['splashscreen'] = data_default_MV('splashscreen');
		$result['intro_page_status'] = query_revo_mobile_variable('"intro_page_status"','sort')[0]->description;

	    	$intro_page = true;
		if (!empty($get)) {
			foreach ($get as $key) {

				if ($key->slug == 'splashscreen') {
					$result['splashscreen'] =  [
						'slug' => $key->slug,
						"title" => '',
						"image" => $key->image,
						"description" => $key->description
					];
				}

				if ($key->slug == 'intro_page') {
					$result['intro'][] = [
						'slug' => $key->slug,
						"title" => $key->title,
						"image" => $key->image,
						"description" => $key->description
					];

				    $intro_page = false;
				}
			}
		}

		if ($intro_page) {
			for ($i=1; $i < 4; $i++) { 
				$result['intro'][] = data_default_MV('intro_page_'.$i);
			}
		}

		if ($type == 'rest') {
			echo json_encode($result);
			exit();
		}else{
			return $result;
		}
	}

	function rest_add_remove_wistlist($type = 'rest'){
		require (plugin_dir_path( __FILE__ ).'../helper.php');
		
		$result['product_id'] = cek_raw('product_id');
		$user_id = wp_validate_auth_cookie(cek_raw('cookie'), 'logged_in');
		if ($user_id) {
			if (!empty($result['product_id'])) {
				$get = query_hit_products($result['product_id'],$user_id);
				if (@cek_raw('check')) {
					if ($get->is_wistlist == 0) { 
						$result['type'] = 'check';
						$result['message'] = false;
					}else{
						$result['type'] = 'check';
						$result['message'] = true;
					}
				}else{
					if ($get->is_wistlist == 0) {
					
						$wpdb->insert('revo_hit_products',                  
						        [
						            'products' => $result['product_id'],
						            'ip_address' => '',
						            'type' => 'wistlist',
						            'user_id' => $user_id,
						        ]);

						if (empty($wpdb->show_errors())) {
							$result['type'] = 'add';
							$result['message'] = 'success';
						}else{
							$result['type'] = 'add';
							$result['message'] = 'error';
						}
					}else{
						$product_id = $result['product_id'];
						$wpdb->query($wpdb->prepare("DELETE FROM `revo_hit_products` WHERE products = '$product_id' AND user_id = '$user_id' AND type = 'wistlist'"));

						if (empty($wpdb->show_errors())) {
							$result['type'] = 'remove';
							$result['message'] = 'success';
						}else{
							$result['type'] = 'remove';
							$result['message'] = 'error';
						}
					}
				}
			}else{
				$result['type'] = 'Empty Product id !';
				$result['message'] = 'error';
			}
		}else{
			$result['type'] = 'Users tidak ditemukan !';
			$result['message'] = 'error';
		}

		if ($type == 'rest') {
			echo json_encode($result);
			exit();
		}else{
			return $result;
		}
	}
	
	function rest_list_wistlist($type = 'rest'){
		require (plugin_dir_path( __FILE__ ).'../helper.php');
		$list_products = '';

		$cookie = cek_raw('cookie');

		$user_id = wp_validate_auth_cookie($cookie, 'logged_in');
		if ($user_id) {
			$get = query_all_hit_products($user_id);
			if (!empty($get)) {
				$list_products = [];
				foreach ($get as $key) {
					$list_products[] = $key->products;
				}
				if (is_array($list_products)) {
					$list_products = implode(",",$list_products);
				}
			}
		}

		$result = [
					'products' => $list_products
				];

		if ($type == 'rest') {
			echo json_encode($result);
			exit();
		}else{
			return $result;
		}
	}

	function rest_key_firebase($type = 'rest'){
		
		$key = access_key();
		$result = array(
					 	"serverKey" => 'AAAALwNKHLc:APA91bGY_AkY01vJ_aGszm7yIjLaNbaAM1ivPlfigeFscdSVuUx3drCRGxyIRgLTe7nLB-5_5rF_ShlmqVXCUmrSd_uaJdcEV43MLxUeFrzmKCzyZzBB7AUlziIGxIH0phtw5VNqgY2Z',
					 	"apiKey" => 'AIzaSyCYkikCSaf91MbO6f3xEkUgFRDqHeNZgNE',
		              	"authDomain" => 'revo-woo.firebaseapp.com',
		              	"databaseURL" => 'https://revo-woo.firebaseio.com',
		              	"projectId" => 'revo-woo',
		              	"storageBucket" => 'revo-woo.appspot.com',
		              	"messagingSenderId" => '201918651575',
		              	"appId" => '1:201918651575:web:dda924debfb0121cf3c132',
		              	"measurementId" => 'G-HNR4L3Z0JE',
				);

		if (isset($key->firebase_servey_key)) {
			$result['serverKey'] = $key->firebase_servey_key;
		}

		if (isset($key->firebase_api_key)) {
			$result['apiKey'] = $key->firebase_api_key;
		}

		if (isset($key->firebase_auth_domain)) {
			$result['authDomain'] = $key->firebase_auth_domain;
		}

		if (isset($key->firebase_database_url)) {
			$result['authDomain'] = $key->firebase_database_url;
		}

		if (isset($key->firebase_database_url)) {
			$result['databaseURL'] = $key->firebase_database_url;
		}

		if (isset($key->firebase_project_id)) {
			$result['projectId'] = $key->firebase_project_id;
		}

		if (isset($key->firebase_storage_bucket)) {
			$result['storageBucket'] = $key->firebase_storage_bucket;
		}

		if (isset($key->firebase_messaging_sender_id)) {
			$result['messagingSenderId'] = $key->firebase_messaging_sender_id;
		}

		if (isset($key->firebase_app_id)) {
			$result['appId'] = $key->firebase_app_id;
		}

		if (isset($key->firebase_measurement_id)) {
			$result['measurementId'] = $key->firebase_measurement_id;
		}

		if ($type == 'rest') {
			echo json_encode($result);
			exit();
		}else{
			return $result;
		}
	}

	function rest_token_user_firebase($type = 'rest'){

		require (plugin_dir_path( __FILE__ ).'../helper.php');
		
		$data['token'] = cek_raw('token');
		$cookie = cek_raw('cookie');

		$result = ['status' => 'error','message' => 'Gagal Input Token !'];
		$insert = true;

		if (!empty($data['token'])) {
			if ($cookie) {
				$user_id = wp_validate_auth_cookie($cookie, 'logged_in');
				if ($user_id) {
					$data['user_id'] = $user_id;
					$get = get_user_token(" WHERE user_id = '$user_id'  ");
					if (!empty($get)) {
						$insert = false;
						$wpdb->update('revo_token_firebase',$data,['user_id' => $user_id]);
						if (@$wpdb->show_errors == false) {
				            $result = ['status' => 'success','message' => 'Update Token Berhasil !'];
				        }
					}
				}

			}

			if ($insert) {
				$wpdb->insert('revo_token_firebase',$data);
				if (@$wpdb->show_errors == false) {
		            $result = ['status' => 'success','message' => 'Insert Token Berhasil !'];
		        }
			}
		}

		if ($type == 'rest') {
			echo json_encode($result);
			exit();
		}else{
			return $result;
		}
	}

	function rest_check_variation($type = 'rest'){

		require (plugin_dir_path( __FILE__ ).'../helper.php');
		
		$product_id = cek_raw('product_id');
		$variation = cek_raw('variation');

		$result = ['status' => 'error','variation_id' => 0];

		if (!empty($product_id)) {

			if ($variation) {
				global $woocommerce;

				$data = [];
				foreach ($variation as $key) {
					$key->column_name = str_replace(" ", "-", strtolower($key->column_name));
					$data["attribute_".$key->column_name] .= $key->value;
					
				}

				if ($data) {
					$data_store = new WC_Product_Data_Store_CPT();
				    $product_object = wc_get_product($product_id);
				    $variation_id = $data_store->find_matching_product_variation($product_object, $data);

				    if ($variation_id) {
				    	$revo_loader = load_Revo_Flutter_Mobile_App_Public();
		
				    	$variableProduct = wc_get_product($variation_id);
				    	$result['status'] = 'success';
				    	$result['data'] = $revo_loader->reformat_product_result($variableProduct);
				    	$result['variation_id'] = $variation_id;
				    }
				}
			}
		}
            

		if ($type == 'rest') {
			echo json_encode($result);
			exit();
		}else{
			return $result;
		}
	}

	function rest_list_orders($type = 'rest'){

		require (plugin_dir_path( __FILE__ ).'../helper.php');
		
		$cookie = cek_raw('cookie');
		$page = cek_raw('page');
		$limit = cek_raw('limit');
		$order_by = cek_raw('order_by');
		$order_id = cek_raw('order_id');
		$status = cek_raw('status');
		$search = cek_raw('search');

		
		$result = [];
		if ($cookie) {
			$user_id = wp_validate_auth_cookie($cookie, 'logged_in');

			$revo_loader = load_Revo_Flutter_Mobile_App_Public();
			if ($order_id) {
				$customer_orders = wc_get_order($order_id);
				if ($customer_orders) {
					$get  = $revo_loader->get_formatted_item_data($customer_orders);
					if (isset($get["line_items"])) {
						for ($i=0; $i < count($get["line_items"]); $i++) { 
								$image_id = wc_get_product($get["line_items"][$i]["product_id"])->get_image_id();
								$get["line_items"][$i]['image'] = wp_get_attachment_image_url( $image_id, 'full' );
						}
					}

					if ($get['customer_id'] == $user_id) {
							$result[] = $get;
					}
				}
			}else{

				$where = array(
			                'meta_key' => '_customer_user',
			                'orderby' => 'date',
			                'order' => ($order_by ? $order_by : "DESC"),
			                'customer_id' => $user_id,
			                'page' => ($page ? $page : "1"),
			                'limit' => ($limit ? $limit : "10"),
			                'parent' => 0
			            );

				if ($status) {
					// Order status. Options: pending, processing, on-hold, completed, cancelled, refunded, failed,trash. Default is pending.
					$where['status'] = $status;
				}

				$customer_orders = wc_get_orders($where);

				foreach ($customer_orders as $key => $value) {
	                $get  = $revo_loader->get_formatted_item_data( $value );

	                if ($get) {
	                	if ($search) {
	                		$show = false;
		                	if (isset($get["line_items"])) {
		                		for ($i=0; $i < count($get["line_items"]); $i++) { 
		                			$product_name = strtolower($get["line_items"][$i]["name"]);
		                			if (strpos($product_name, $search) !== FALSE) {
									   	$show = true;
									   	$image_id = wc_get_product($get["line_items"][$i]["product_id"])->get_image_id();
										$get["line_items"][$i]['image'] = wp_get_attachment_image_url( $image_id, 'full' );
									}
		                		}
		                	}
		                	if ($show) {
		                		$result[] = $get;
		                	}
		                }else{
		                	if (isset($get["line_items"])) {
		                		for ($i=0; $i < count($get["line_items"]); $i++) { 
								   	$show = true;
								   	$image_id = wc_get_product($get["line_items"][$i]["product_id"])->get_image_id();
									$get["line_items"][$i]['image'] = wp_get_attachment_image_url( $image_id, 'full' );
		                		}
		                	}
	                		$result[] = $get;
		                }
	                }
	            }

	            
				// print_r($image_url);
				// die();
			}
		}
            

		if ($type == 'rest') {
			echo json_encode($result);
			exit();
		}else{
			return $result;
		}
	}

	function rest_list_review($type = 'rest'){

		$result = ['status' => 'error','message' => 'Login required !'];

		$cookie = cek_raw('cookie');
		$limit = cek_raw('limit');
		$post_id = cek_raw('post_id');
		$limit = cek_raw('limit');
		$page = cek_raw('page');

		$args = array( 
            'number'      => $limit, 
            'status'      => 'approve', 
            'post_status' => 'publish', 
            'post_type'   => 'product',
        );

        if ($cookie) {
			$user_id = wp_validate_auth_cookie($cookie, 'logged_in');
			$args['user_id'] = $user_id;
		}

		if ($post_id) {
			$args['post_id'] = $post_id;
		}

		if ($limit) {
			$args['number'] = $limit;
		}

		if ($page) {
			$args['offset'] = $page;
		}

		$comments = get_comments( $args );

		$result = [];
		foreach ($comments as $key) {
			$product = wc_get_product($key->comment_post_ID);
			$result[] = array(
							'product_id' => $key->comment_post_ID, 
							'title_product' => $product->get_name(), 
							'image_product' => wp_get_attachment_image_url( $product->get_image_id(), 'full' ), 
							'content' => $key->comment_content, 
							'star' => get_comment_meta( $key->comment_ID, 'rating', true ), 
							'comment_author' => $key->comment_author, 
							'user_id' => $key->user_id,
							'comment_date' => $key->comment_date,  
						);
		}

		if ($type == 'rest') {
			echo json_encode($result);
			exit();
		}else{
			return $result;
		}
	}

	function rest_list_notification($type = 'rest'){

		require (plugin_dir_path( __FILE__ ).'../helper.php');

		$result = ['status' => 'error','message' => 'Login required !'];

		$cookie = cek_raw('cookie');

		if ($cookie) {
			$user_id = wp_validate_auth_cookie($cookie, 'logged_in');
			$data_notification = $wpdb->get_results("SELECT * FROM revo_notification WHERE user_id = '$user_id' AND type = 'order'  AND is_read = 0 ORDER BY created_at DESC", OBJECT);

			$revo_loader = load_Revo_Flutter_Mobile_App_Public();
			$result = [];
			foreach ($data_notification as $key => $value) {
				$order_id = (int) $value->target_id;
				$imageProduct="";
				if ($order_id && $imageProduct=="") {
					$customer_orders = wc_get_order($order_id);
					if ($customer_orders) {
						$get  = $revo_loader->get_formatted_item_data($customer_orders);
						if (isset($get["line_items"])) {
							for ($i=0; $i < count($get["line_items"]); $i++) { 
								$image_id = wc_get_product($get["line_items"][$i]["product_id"])->get_image_id();
								$imageProduct = wp_get_attachment_image_url( $image_id, 'full' ) ?? get_logo();
							}
						}
					}
				}

				array_push($result, [
					'user_id' => (int) $value->product_id,
					'order_id' => (int) $value->target_id,
					'status' => $value->message,
					'image' => $imageProduct,
					'created_at' => $value->created_at,
				]);
			}
		}

		if ($type == 'rest') {
			echo json_encode($result);
			exit();
		}else{
			return $result;
		}
	}
	
	function rest_read_notification($type = 'rest'){

		require (plugin_dir_path( __FILE__ ).'../helper.php');

		$result = ['status' => 'error','message' => 'Login required !'];

		$cookie = cek_raw('cookie');
		$id = cek_raw('id');

		if ($cookie) {
			$user_id = wp_validate_auth_cookie($cookie, 'logged_in');

			$data['is_read'] = 1;
			$wpdb->update('revo_notification',$data,[
							'id' => $id,
							'user_id' => $user_id,
						]);
			if (@$wpdb->show_errors == false) {
	            $result = ['status' => 'success','message' => 'Berhasil Dibaca !'];
	        }
		}

		if ($type == 'rest') {
			echo json_encode($result);
			exit();
		}else{
			return $result;
		}
	}

	function notif_new_order($order_id){

		require (plugin_dir_path( __FILE__ ).'../helper.php');
		
		$order = wc_get_order($order_id);

		$order_number = $order->get_order_number();
		$user_id = $order->get_user_id();
		$title = 'ORDER: #' . $order_number;
        	$message = 'YOUR ORDER ' . strtoupper($order->status);

		$wpdb->insert('revo_notification',
						[
							'type' => "order",
							'target_id' => $order_number,
							'message' => $order->status,
							'user_id' => $user_id,
						]);

		$get = get_user_token(" WHERE user_id = '$user_id' ");

		if (!empty($get)) {
			foreach ($get as $key) {
				$token = $key->token;
				$notification = array(
							'title' => $title, 
							'body' => $message, 
							'icon' => get_logo(), 
						);
							// 'click_action' => '', 
				$extend['id'] = $order_number;
				$extend['type'] = "order";

				send_FCM($token,$notification,$extend);
			}
		}
	}

	function rest_disabled_service($type = 'rest')
	{
		require (plugin_dir_path( __FILE__ ).'../helper.php');

		$result = ['status' => 'error','message' => 'Cabut License Gagal !'];

		$query = "SELECT * FROM `revo_mobile_variable` WHERE slug = 'license_code'";
  		$get = $wpdb->get_row($query, OBJECT);
  		if (!empty($get->description)) {
  			$get = json_decode($get->description);
  			if (!empty($get)) {
  				if ($get = $get->license_code == cek_raw('code')) {
  					if ($get) {
						$data = data_default_MV('license_code');
						$wpdb->update('revo_mobile_variable',$data,['slug' => 'license_code']);
						if (@$wpdb->show_errors == false) {
				            $result = ['status' => 'success','message' => 'Cabut License Berhasil !'];
				        }
					}
  				}
  			}
  		}

		if ($type == 'rest') {
			echo json_encode($result);
			exit();
		}else{
			return $result;
		}
	}

	function rest_topup_woowallet($type = 'rest'){

		require (plugin_dir_path( __FILE__ ).'../helper.php');
		
		$cookie;
		if (isset($_GET['cookie'])){
			$cookie = $_GET['cookie'];
		}

		if ($cookie) {
			$userId = wp_validate_auth_cookie($cookie, 'logged_in');

			if (!$userId) {
				echo "Invalid authentication cookie. Please try to login again!";
				return;
			}
			// Check user and authentication
			$user = get_userdata($userId);
			if ($user) {        
				wp_set_current_user($userId, $user->user_login);
				wp_set_auth_cookie($userId);
			}
		}
            

		$urlAccount = get_permalink( get_option('woocommerce_myaccount_page_id') ).'woo-wallet/add';
		wp_redirect( $urlAccount );
		exit();
	}
    
    function rest_transfer_woowallet($type = 'rest'){

		require (plugin_dir_path( __FILE__ ).'../helper.php');
		$cookie;
		if (isset($_GET['cookie'])){
			$cookie = $_GET['cookie'];
		}

		if ($cookie) {
			$userId = wp_validate_auth_cookie($cookie, 'logged_in');

			if (!$userId) {
				echo "Invalid authentication cookie. Please try to login again!";
				return;
			}
			// Check user and authentication
			$user = get_userdata($userId);
			if ($user) {        
				wp_set_current_user($userId, $user->user_login);
				wp_set_auth_cookie($userId);
			}
		}
            

		$urlAccount = get_permalink( get_option('woocommerce_myaccount_page_id') ).'woo-wallet/transfer';
		wp_redirect( $urlAccount );
		exit();
	}
	
	// function rest_data_attribute_bycategory($type = 'rest'){

	// 	require (plugin_dir_path( __FILE__ ).'../helper.php');

	// 	$category = cek_raw('category');
		
	// 	if (!empty($category)) {
    //         $categories = explode(',', $category);
    //         $categoriesSlug = [];
    //         if (is_array($categories)) {
    //             for ($i=0; $i < count($categories); $i++) {
    //                 $term = get_term_by('id', $categories[$i], 'product_cat', 'ARRAY_A');
    //                 if (!empty($term)) {
    //                     $categoriesSlug[] = $term['slug'];
    //                 }
    //             }
    //         }
    //         $args['category'] = $categoriesSlug;
    //     }
        
    //     $args['status'] = 'publish';
		
	// 	$result = array();
		
	// 	foreach( wc_get_products($args) as $product ){
		    		
	// 		$all_prices[] = $product->get_price();
				
	// 		foreach( $product->get_attributes() as $taxonomy => $attribute ){
	// 			$attribute_name = wc_attribute_label( $taxonomy );
				
	// 			foreach ( $attribute->get_terms() as $term ){
				
	// 			    $args['tax_query'] = array(
	// 					array(
	// 						'taxonomy'        => $taxonomy,
	// 						'field'           => 'slug',
	// 						'terms'           =>  array($term->name),
	// 						'operator'        => 'IN',
	// 					),
	// 				);

	// 				$products = wc_get_products( $args );
					
	// 			    $data_filter[] = array($taxonomy, $attribute_name, $term->term_id, $term->name, count($products));
	// 			    $data_taxonomy[] = array($taxonomy, $attribute_name);
				    
	// 			}
				
	// 		}
			
	// 	}
		
	// 	$data_taxonomy = array_map("unserialize", array_unique(array_map("serialize", $data_taxonomy)));

	// 	$data_filter = array_map("unserialize", array_unique(array_map("serialize", $data_filter)));
		    
	// 	for ($i=0; $i < (count($data_filter)-1); $i++) { 
		    
	// 	    $taxonomy = $data_filter[$i][0];
	// 	    $attribute_name = $data_filter[$i][1];
	// 	    $term_id = $data_filter[$i][2];
	// 	    $name = $data_filter[$i][3];
	// 	    $count = $data_filter[$i][4];
		    
	// 	    if(!empty($taxonomy)){
	// 	        $result['data_filter'][$taxonomy][] = array('attribute_name' => $attribute_name, 'term_id' => $term_id, 'name' => $name, 'product_count' => $count);
	// 	    }
            
    //     }
		
	// 	$result['range_price'] = ['min_price' => floor(min($all_prices)), 'max_price' => ceil(max($all_prices))];

	// 	if ($type == 'rest') {
	// 		echo json_encode($result);
	// 		exit();
	// 	}else{
	// 		return $result;
	// 	}
	// }

	// function rest_data_woo_discount_rules( $type = 'rest'){

	// 	require (plugin_dir_path( __FILE__ ).'../helper.php');

	// 	$woo_discount = get_option('woo-discount-config-v2')['calculate_discount_from'];

	// 	if (!empty($woo_discount)) {
	// 		$result['calculate_discount_from'] = !empty($woo_discount) ? $woo_discount : 'sale_price';

			
	// 		$table_name = $wpdb->prefix . 'wdr_rules';

	// 		$get_rules = $wpdb->get_results("SELECT * FROM `$table_name` WHERE `enabled` = 1", OBJECT);

	// 		if (!empty($get_rules)) {

	// 			foreach($get_rules as $value) {

	// 				$rules = json_decode($value->bulk_adjustments);

	// 				$operator = $rules->operator;

	// 				$ranges = $rules->ranges;

	// 				if ($operator == 'product_cumulative') {
	// 					$result['discount_rules'] = array('operator' => $operator, 'ranges' => $ranges);
	// 				} 
	// 				elseif ($operator == 'variation') {
	// 					$result['discount_rules'] = array('operator' => $operator, 'ranges' => $ranges);
	// 				} 
	// 				elseif ($operator == 'product') {
	// 					$result['discount_rules'] = array('operator' => $operator, 'ranges' => $ranges);
	// 				}

	// 			}

	// 		} else {
	// 			$result = ['status' => 'error','message' => 'data not found !'];
	// 		}

	// 	} else {
	// 		$result = ['status' => 'error','message' => 'plugin woo discount rules not installed !'];
	// 	}
		
	// 	return $result;
		
	// }
	
    // function handle_price_range_query_var($query, $query_vars) {
        
    //     if (!empty($query_vars['price_range'])) {
    //         // $price_range = esc_attr($query_vars['price_range']);
            
    //         $price_range = explode( '|', esc_attr($query_vars['price_range']) );
    
    //         if (is_array($price_range) && count($price_range) == 2) {
    
    //             $query['meta_query'][] = array(
    //                 'key' => '_price',
    //                 'value' => array(reset($price_range), end($price_range)),
    //                 'compare' => 'BETWEEN',
    //                 'type' => 'NUMERIC'
    //             );
    
    //             $query['orderby'] = 'meta_value_num'; // sort by price
    //             $query['order'] = 'ASC'; // In ascending order
    //         }
    //     }
        
    //     return $query;
    // }

	// function rest_insert_chat($type = 'rest'){
		
	// 	$cookie = cek_raw('cookie');
	// 	$message = cek_raw('message');
	// 	// seller_id & product_id opsional
	// 	$post_id = cek_raw('post_id');
	// 	$receiver_id = cek_raw('receiver_id'); 
	// 	$type = cek_raw('type');
	// 	$image = cek_raw('image');
		
	// 	$result = ['status' => 'error','message' => 'Target ID Required ! product_id & seller_id'];
	// 	if (!empty($post_id) AND !empty($receiver_id)) {
	// 		$result = ['status' => 'error','message' => 'Login required !'];
	// 		if ($cookie) {
	// 			require (plugin_dir_path( __FILE__ ).'../helper.php');
	// 			$user_id = wp_validate_auth_cookie($cookie, 'logged_in');

	// 			$result = ['status' => 'error','message' => 'User Not Found !'];
	// 			if ($user_id) {
	// 				$get_message = get_conversations($user_id,$receiver_id);
	// 				$result = ['status' => 'error','message' => 'system error !'];
	// 				if (empty($get_message)) {
	// 					$wpdb->insert('revo_conversations',                  
	// 			        [
	// 			            'sender_id' => $user_id,
	// 			            'receiver_id' => $receiver_id,
	// 			        ]);

	// 					$conversation_id = $wpdb->insert_id;
	// 				}else{
	// 					$conversation_id = $get_message->id;
	// 				}	

	// 				if ($conversation_id) {
	// 					$wpdb->insert('revo_conversation_messages',                  
	// 			        [
	// 			            'conversation_id' => $conversation_id,
	// 			            'sender_id' => $user_id,
	// 			            'receiver_id' => $receiver_id,
	// 			            'message' => $message,
	// 			            'type' => $type,
	// 			            'image' => $image,
	// 			            'post_id' => $post_id,
	// 			        ]);
	// 				}
					
	// 				$result = ['status' => 'success','message' => 'success input message !'];
	// 			}
	// 		}
	// 	}

	// 	if ($type == 'rest') {
	// 		echo json_encode($result);
	// 		exit();
	// 	}else{
	// 		return $result;
	// 	}
	// }

	// function rest_list_user_chat($type = 'rest'){
	// 	$cookie = cek_raw('cookie');

	// 	$result = ['status' => 'error','message' => 'Login required !'];

	// 	if ($cookie) {
	// 		require (plugin_dir_path( __FILE__ ).'../helper.php');
	// 		$user_id = wp_validate_auth_cookie($cookie, 'logged_in');
	// 		$result = ['status' => 'error','message' => 'User Not Found !'];
	// 		if ($user_id) {
	// 			$get = get_conversations($user_id);
	// 			$result = [];
	// 			$revo_loader = load_Revo_Flutter_Mobile_App_Public();
	// 			foreach ($get as $index => $key) {
	// 			    $user_message_id = $key->receiver_id;
	// 			    if($key->status == 'buyer'){
	// 			        $user_message_id = $key->sender_id;
	// 			    }
				    
	// 				$user = get_userdata($user_message_id);
					
	// 				$username = $user->user_nicename;
	// 				$photo = get_avatar_url($user_message_id);
					
	// 				if($key->status == 'seler'){
	// 					$_POST['disabled_cookie'] = true;
	// 				    $get = $revo_loader->get_wcfm_vendor_list(1,$user_message_id);
					
    // 					if (!empty($get)) {
    // 					    $photo = $get[0]['icon'];
    // 					    $username = $get[0]['name'];
    // 					}
	// 				}
					
	// 				$result[$index]['id'] = $key->id;
	// 				$result[$index]['receiver_id'] = $user_message_id;
	// 				$result[$index]['photo'] = $photo;
	// 				$result[$index]['seller_name'] = $username;
	// 				$result[$index]['status'] = $key->status;
	// 				$result[$index]['created_at'] = $key->created_at;
	// 			}
	// 		}
	// 	}

	// 	if ($type == 'rest') {
	// 		echo json_encode($result);
	// 		exit();
	// 	}else{
	// 		return $result;
	// 	}
	// }

	// function rest_detail_chat($type = 'rest'){
	// 	$cookie = cek_raw('cookie');
	// 	$chat_id = cek_raw('chat_id');

	// 	$result = ['status' => 'error','message' => 'Login required !'];

	// 	if ($cookie) {
	// 		require (plugin_dir_path( __FILE__ ).'../helper.php');
	// 		$user_id = wp_validate_auth_cookie($cookie, 'logged_in');
	// 		$result = ['status' => 'error','message' => 'User Not Found !'];
	// 		if ($user_id) {
	// 			$result = get_conversations_detail($user_id,$chat_id);
	// 			$revo_loader = load_Revo_Flutter_Mobile_App_Public();
	// 			foreach ($result as $index => $key) {
	// 				if (empty($key->image)) {
	// 					$key->image = NULL;
	// 				}
	// 				if ($key->type == 'produk') {
	// 					$_POST['product_id'] = $key->post_id;
	// 					$list_products = $revo_loader->get_products();
	// 					$key->subject[] = array(
	// 									'product_id' => $list_products[0]['id'], 
	// 									'product_name' => $list_products[0]['name'], 
	// 									'product_average_rating' => $list_products[0]['average_rating'], 
	// 									'product_rating_count' => $list_products[0]['rating_count'], 
	// 									'product_price' => $list_products[0]['price'], 
	// 									'product_formatted_price' => $list_products[0]['formated_price'], 
	// 									'product_images' => $list_products[0]['images'], 
	// 								);
	// 				}else{
	// 					$key->subject = [];
	// 				}
	// 			}
	// 		}
	// 	}

	// 	if ($type == 'rest') {
	// 		echo json_encode($result);
	// 		exit();
	// 	}else{
	// 		return $result;
	// 	}
	// }

?>
