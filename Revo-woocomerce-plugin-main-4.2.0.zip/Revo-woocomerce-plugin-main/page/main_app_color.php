<!doctype html>
<?php
  require (plugin_dir_path( __FILE__ ).'../helper.php');

  $query_app_color = "SELECT * FROM `revo_mobile_variable` WHERE slug = 'app_color' LIMIT 2 ";
  $data_app_color = $wpdb->get_results($query_app_color, OBJECT);

  if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (@$_POST['slug']) {
      if ($_POST['slug'] == 'app_color') {

        $success = 0;
        $where_primary = array(
          'slug' => 'app_color',
          'title' => 'primary',
        );

        $desc_prim_col = str_replace("#","",$_POST['prim_color']);

        $success = insert_update_MV($where_primary,$_POST['id_prim_color'],$desc_prim_col);

        $update_at = array('update_at' => date('Y-m-d H:i:s'));

        if ($success) {
          $wpdb->update('revo_mobile_variable',$update_at,['id' => $_POST['id_prim_color']]);
        }

        $where_secondary = array(
          'slug' => 'app_color',
          'title' => 'secondary',
        );

        $desc_sec_col = str_replace("#","",$_POST['sec_color']);

        $success = insert_update_MV($where_secondary,$_POST['id_sec_color'],$desc_sec_col);

        if ($success) {
          $wpdb->update('revo_mobile_variable',$update_at,['id' => $_POST['id_sec_color']]);
        }

        if ($success > 0) {
          $data_app_color = $wpdb->get_results($query_app_color, OBJECT);
          $alert = array(
            'type' => 'success',
            'title' => 'Success !',
            'message' => 'Application Color Updated Successfully',
          );
        }else{
          $alert = array(
            'type' => 'error',
            'title' => 'error !',
            'message' => 'Contact Failed to Update',
          );
        }

        $_SESSION["alert"] = $alert;

      }
    }
  }

?>
<html class="fixed sidebar-light">
<?php include (plugin_dir_path( __FILE__ ).'partials/_css.php'); ?>
<body>
  <?php include (plugin_dir_path( __FILE__ ).'partials/_header.php'); ?>
  <div class="container-fluid">
    <?php include (plugin_dir_path( __FILE__ ).'partials/_alert.php'); ?>
    <section class="panel">
      <div class="inner-wrapper pt-0">

        <!-- start: sidebar -->
        <?php include (plugin_dir_path( __FILE__ ).'partials/_new_sidebar.php'); ?>
        <!-- end: sidebar -->

      <section role="main" class="content-body p-0 pl-0">
          <section class="panel mb-3">
            <div class="panel-body">
              <div class="row border-bottom-primary">
                <div class="col-md-12">
                  <h4 style="margin-bottom: 35px">Application Color</h4>
                </div>
                <form class=" col-md-12 form-horizontal form-bordered" method="POST" action="#" enctype="multipart/form-data">
                    <div class="form-group">
                        <label class="col-md-2 control-label text-left" for="inputDefault">Primary Color</label>
                        <div class="col-md-10">
                            <?php
                                $id = 0;
                                $value = '';
                                if ($data_app_color) {
                                  foreach ($data_app_color as $key){
                                    if ($key->title == 'primary') {
                                      $id = $key->id;
                                      $value = '#'.$key->description;
                                    }
                                  }
                                }
                              ?>
                                  <input type="color" class="form-control" name="prim_color" placeholder="ex: ED1D1D" value="<?= $value ?>" required>
                                  <input type="hidden" name="id_prim_color" value="<?php echo $id  ?>">
                              <?php

                              ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2 control-label text-left" for="inputDefault">Secondary Color</label>
                        <div class="col-md-10">
                            <?php
                              $id = 0;
                              $value = '';
                              if ($data_app_color) {
                                foreach ($data_app_color as $key){
                                  if ($key->title == 'secondary') {
                                    $id = $key->id;
                                    $value = '#'.$key->description;
                                  }
                                }
                              }
                            ?>
                            <input type="color" class="form-control" name="sec_color" placeholder="ex: 960000" value="<?= $value ?>" required>
                            <input type="hidden" name="id_sec_color" value="<?php echo $id ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-12 text-right">
                            <input type="hidden" name="slug" value="app_color">
                            <button type="submit" class="btn btn-primary">Update App Color</button>
                        </div>
                    </div>
                </form>
              </div>
            </div>
          </section>
      </section>
    </div>
    </section>
  </div>
</body>
